int x, y, z;

int foo(void)
{
    x = y + z;
    y = x - z;
    z = y * x;
}
