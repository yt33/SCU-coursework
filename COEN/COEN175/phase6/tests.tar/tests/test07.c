int putchar(int x);

int foo(int a, int b)
{
    putchar(a + b);
    return a - b;
}
