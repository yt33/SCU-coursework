int main(void)
{
    int x, y, z;

    x = 1;
    y = 2;
    z = 3;

    if (y == z)
	printf("oops!\n");

    if (x < y)
	printf("hello\n");
    else
	printf("there\n");

    if (x > y)
	printf("howdy\n");
    else
	printf("partner\n");
}
