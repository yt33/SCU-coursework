int putchar(int x);

int main(void)
{
    putchar(64 + 1);
    putchar(10);
}
