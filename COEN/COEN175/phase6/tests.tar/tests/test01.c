int x, y, z;

int foo(void)
{
}
