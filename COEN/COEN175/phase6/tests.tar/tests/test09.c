int main(void)
{
    int a[3];

    a[0] = 0;
    a[1] = 1;
    a[2] = 2;

    printf("%d\n", a[0]);
    printf("%d\n", a[1]);
    printf("%d\n", a[2]);
}
