int main(void)
{
    int x, y, z;

    x = 2;
    y = 3;
    z = x * y;
    printf("%d\n", x);
    printf("%d\n", y);
    printf("%d\n", z);
}
