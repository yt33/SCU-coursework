int foo(void)
{
}
