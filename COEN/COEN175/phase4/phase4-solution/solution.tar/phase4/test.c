int main(void)
{
    char c, a[5], *p;

    p = c + a;
    p = p - c;
}
