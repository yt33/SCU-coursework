int main(void)
{
    int x, *p;


    x = foo();
    x = bar(1, 2, 3);
    p = malloc();		/* invalid operands to binary = */
}
