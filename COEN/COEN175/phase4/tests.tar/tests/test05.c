int foo(int x, int y)
{
    int *p, z;

    x || y;
    x || 0;
    p || z;
    foo && p;			/* invalid operands to binary && */

    p = (int *) z;
    z = (int) p;
    p = (int *) (int **) p;
    p = (int *) (double) p;	/* invalid operand in cast expression */
}
