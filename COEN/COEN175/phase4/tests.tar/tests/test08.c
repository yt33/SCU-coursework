int main(void)
{
    double a, b, c, *q;

    a = b + c;
    a = b + 1;
    a = b < c;
    a = b == c;
    q = b;		/* invalid operands to binary = */
    *q = b;
}
