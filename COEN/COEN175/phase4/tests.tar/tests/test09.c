double *f(double *s, double *t)
{
    double *p;

    p = s;

    while (*p != 0) {
	*p = *t;
	p = p + 1;
	t = t + 1;
    }

    *p = 0;
    return s;
}

int main(void)
{
    double x, y, z;
    double *q;


    y = x % z;			/* invalid operands to binary % */
    x = y * 3.14159 - z / 2;
    q = f(q, q);
}
