# ifndef GENERATE_H
# define GENERATE_H
#include "Scope.h"
#include "Tree.h"

void generateGlobals(const Symbols &globals);

# endif /* GENERATE_H */